// src/Cart.js
import React, { useContext } from 'react';
import { CartContext } from './CartContext';

const Cart = () => {
  const { cart, removeFromCart } = useContext(CartContext);

  return (
    <div className="container">
      <h1>Cart</h1>
      {cart.length === 0 ? (
        <p>No items in the cart.</p>
      ) : (
        <div className="row">
          {cart.map((item, index) => (
            <div className="col" key={index}>
              <div className="card" style={{ width: "18rem" }}>
                <img src={item.imgSrc} className="card-img-top" alt={item.title} height="250px" />
                <div className="card-body">
                  <h5 className="card-title">{item.title}</h5>
                  <p className="card-text">{item.description}</p>
                  <button onClick={() => removeFromCart(item)} className="btn btn-danger">Remove from cart</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Cart;
