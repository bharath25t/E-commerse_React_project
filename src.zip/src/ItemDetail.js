import React from 'react';
import { useParams } from 'react-router-dom';

const ItemDetail = ({ items }) => {
  const { itemId } = useParams();
  const item = items[parseInt(itemId)];

  if (!item) {
    return <div>Item not found</div>;
  }

  return (
    <div className="container">
      <div className="row">
        <div className="col-md-4">
          <img src={item.imgSrc} alt={item.title} height="250px" className="img-fluid" />
        </div>
        <div className="col-md-8">
          <h1>{item.title}</h1>
          <p><strong>Description:</strong> {item.description}</p>
          <p><strong>Price:</strong> {item.price}</p>
        </div>
      </div>
    </div>
  );
};

export default ItemDetail;
